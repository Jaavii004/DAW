#!/bin/bash

# Este script instala un controlador de impresora y agrega una impresora en macOS

# Ruta al controlador de impresora
driver_path="./bizhub_C554_C364.pkg"

# Nombre del controlador de impresora
driver_name="bizhub C554"

# Install PryntControl
sudo sh install_PryntControl.sh 

#activar pryntcontrol
sudo sh activate_PryntControl.sh

# Nombre de la impresora que se va a agregar
printer_name="PryntControl"

# Instalar el controlador de impresora
echo "Instalando el controlador de la impresora..."
sudo installer -pkg "$driver_path" -target /

# Agregar la impresora
echo "Agregando la impresora..."
lpadmin -p "$printer_name" -E -v "pryntcontrol://pryntcontrol" -P "/Library/Printers/PPDs/Contents/Resources/$driver_name" -o printer-is-shared=false

# Imprimir una página de prueba
echo "Imprimiendo una página de prueba..."
lp -d "$printer_name" /System/Library/Frameworks/QuickLook.framework/Versions/A/Resources/QuickLookHTML.qlo/Contents/Resources/PageTemplate.html

echo "Instalación completa."
