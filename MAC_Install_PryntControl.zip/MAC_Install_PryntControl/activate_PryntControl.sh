#!/bin/bash

clear

echo "Activando PryntControl"
launchctl load /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "Fin Activar PryntControl"