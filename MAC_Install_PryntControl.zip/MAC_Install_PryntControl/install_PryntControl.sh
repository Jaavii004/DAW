#!/bin/bash

clear

echo "Instalando PryntControl Print"
#Instalando el backend
cp ./manage/pryntcontrol /usr/libexec/cups/backend/pryntcontrol
chmod 755 /usr/libexec/cups/backend/pryntcontrol
chown root.root /usr/libexec/cups/backend/pryntcontrol
chmod 755 /usr/libexec/cups/backend/smb

#Instalando aplicacion
mkdir /Applications/PryntControl
mkdir /Applications/PryntControl/client
mkdir /Applications/PryntControl/prints
chmod 777 /Applications/PryntControl/prints
mkdir -p /Users/Shared/PryntControl
chmod 777 /Users/Shared/PryntControl
#
cp -Rf ./content/* /Applications/PryntControl/client
cd /Applications/PryntControl/client
tar xopf PryntControlPrint.app.tar
tar xopf service.tar
#Crear el Servicio
touch /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "<?xml version=""1.0"" encoding=""UTF-8""?>" > /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "<!DOCTYPE plist PUBLIC ""-//Apple Computer//DTD PLIST 1.0//EN"" ""http://www.apple.com/DTDs/PropertyList-1.0.dtd"">" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "<plist version=""1.0"">" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "<dict>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	<key>Label</key>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	<string>es.dico.pryntcontrol.popup</string>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	<key>ProgramArguments</key>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	<array>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "		<string>/Applications/PryntControl/client/service/service</string>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	</array>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	<key>RunAtLoad</key>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "	<true/>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "</dict>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist
echo "</plist>" >> /Library/LaunchAgents/es.dico.pryntcontrol.popup.plist

echo "Fin PryntControl Print, recuerde activar PryntControl como usuario"